from sqlalchemy.orm import registry

table_registry = registry()
