from src.models import destinatario_model as destinatario_model
from src.models import emitente_model as emitente_model
from src.models import notaFiscal_model as notaFiscal_model
from src.models import role_model as role_model
from src.models import user_model as user_model
